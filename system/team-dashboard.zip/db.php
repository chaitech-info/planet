<?php
$config = require __DIR__ . '/config.php';
date_default_timezone_set($config['timezone'] ?? 'Asia/Baku');

function db(): PDO
{
    static $pdo = null;
    global $config;
    if ($pdo) {
        return $pdo;
    }
    $c = $config['db'];
    $pdo = new PDO($c['dsn'], $c['user'] ?? null, $c['pass'] ?? null, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
    $sqlite = str_starts_with($c['dsn'], 'sqlite');
    $id = $sqlite ? 'INTEGER PRIMARY KEY AUTOINCREMENT' : 'BIGINT AUTO_INCREMENT PRIMARY KEY';
    $key = $sqlite ? '' : ', KEY idx_created (created_at)';
    $pdo->exec("CREATE TABLE IF NOT EXISTS events (
        id $id,
        user VARCHAR(64) NOT NULL,
        session_id VARCHAR(64) NOT NULL,
        project VARCHAR(128) NOT NULL,
        event VARCHAR(32) NOT NULL,
        tool VARCHAR(64) NOT NULL DEFAULT '',
        summary TEXT NOT NULL,
        created_at INT NOT NULL $key
    )");
    if ($sqlite) {
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_created ON events (created_at)');
    }
    $pdo->exec("CREATE TABLE IF NOT EXISTS sessions (
        user VARCHAR(64) NOT NULL,
        session_id VARCHAR(64) NOT NULL,
        project VARCHAR(128) NOT NULL,
        cwd VARCHAR(512) NOT NULL DEFAULT '',
        status VARCHAR(16) NOT NULL,
        last_prompt TEXT NOT NULL,
        last_summary TEXT NOT NULL,
        edits INT NOT NULL DEFAULT 0,
        tool_count INT NOT NULL DEFAULT 0,
        started_at INT NOT NULL,
        updated_at INT NOT NULL,
        PRIMARY KEY (user, session_id)
    )");
    return $pdo;
}

function json_out($data, int $code = 200): void
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}
