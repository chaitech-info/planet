<?php
require __DIR__ . '/db.php';
session_start();
$error = '';
if (isset($_GET['logout'])) {
    $_SESSION = [];
    session_destroy();
    header('Location: ./');
    exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    usleep(400000);
    if (hash_equals($config['dashboard_password'], (string)($_POST['password'] ?? ''))) {
        session_regenerate_id(true);
        $_SESSION['ok'] = true;
        header('Location: ./');
        exit;
    }
    $error = 'Parol yanlışdır';
}
$authed = !empty($_SESSION['ok']);
?><!doctype html>
<html lang="az">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex">
<title>Komanda Claude</title>
<style>
:root {
  --bg: #f6f6f4; --card: #fff; --text: #1c1c1a; --muted: #6d6d68; --line: #e4e4df;
  --work: #d97706; --wait: #dc2626; --idle: #16a34a; --off: #a3a39c; --accent: #c4552d;
}
@media (prefers-color-scheme: dark) {
  :root { --bg: #161615; --card: #1f1f1d; --text: #ecece8; --muted: #9b9b94; --line: #333330;
          --work: #f59e0b; --wait: #f87171; --idle: #4ade80; --off: #6b6b65; --accent: #e8825c; }
}
* { box-sizing: border-box; }
body { margin: 0; background: var(--bg); color: var(--text); font: 15px/1.45 system-ui, -apple-system, "Segoe UI", sans-serif; }
.wrap { max-width: 1100px; margin: 0 auto; padding: 20px 16px 48px; }
header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px; gap: 12px; }
h1 { font-size: 20px; margin: 0; }
h2 { font-size: 13px; text-transform: uppercase; letter-spacing: .06em; color: var(--muted); margin: 28px 0 10px; }
.meta { color: var(--muted); font-size: 13px; display: flex; gap: 14px; align-items: center; }
a { color: var(--muted); }
.grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 14px; }
.card { background: var(--card); border: 1px solid var(--line); border-radius: 12px; padding: 14px 16px; }
.person { display: flex; align-items: center; gap: 10px; margin-bottom: 10px; }
.avatar { width: 32px; height: 32px; border-radius: 50%; background: var(--accent); color: #fff; display: grid; place-items: center; font-weight: 600; }
.pname { font-weight: 600; }
.pstate { font-size: 12.5px; color: var(--muted); }
.dot { display: inline-block; width: 9px; height: 9px; border-radius: 50%; margin-right: 6px; background: var(--off); vertical-align: 1px; }
.dot.working { background: var(--work); animation: pulse 1.2s ease-in-out infinite; }
.dot.waiting { background: var(--wait); animation: pulse 1.2s ease-in-out infinite; }
.dot.idle { background: var(--idle); }
@keyframes pulse { 50% { opacity: .35; } }
@media (prefers-reduced-motion: reduce) { .dot { animation: none !important; } }
.sess { border-top: 1px solid var(--line); padding: 10px 0 2px; }
.sess:first-of-type { border-top: 0; padding-top: 0; }
.sproj { font-weight: 600; font-size: 14px; }
.sline { color: var(--muted); font-size: 13.5px; overflow-wrap: anywhere; }
.sprompt { margin: 4px 0; font-size: 13.5px; overflow-wrap: anywhere; }
.chips { display: flex; gap: 8px; margin-top: 6px; font-size: 12px; color: var(--muted); }
.empty { color: var(--muted); font-size: 14px; padding: 4px 0; }
.filters { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 10px; }
.filters button { border: 1px solid var(--line); background: var(--card); color: var(--text); border-radius: 999px; padding: 4px 12px; font: inherit; font-size: 13px; cursor: pointer; }
.filters button.on { background: var(--accent); border-color: var(--accent); color: #fff; }
.feed .row { display: grid; grid-template-columns: 56px 80px 1fr; gap: 10px; padding: 8px 0; border-top: 1px solid var(--line); font-size: 13.5px; }
.feed .row:first-child { border-top: 0; }
.feed .t { color: var(--muted); font-variant-numeric: tabular-nums; }
.feed .u { font-weight: 600; }
.feed .s { overflow-wrap: anywhere; }
.feed .s small { color: var(--muted); }
.login { max-width: 320px; margin: 18vh auto 0; }
.login input, .login button { width: 100%; font: inherit; padding: 10px 12px; border-radius: 8px; border: 1px solid var(--line); margin-top: 10px; }
.login input { background: var(--card); color: var(--text); }
.login button { background: var(--accent); border-color: var(--accent); color: #fff; cursor: pointer; }
.err { color: var(--wait); margin-top: 8px; font-size: 14px; }
@media (max-width: 520px) { .feed .row { grid-template-columns: 48px 1fr; } .feed .u { display: none; } }
</style>
</head>
<body>
<div class="wrap">
<?php if (!$authed): ?>
  <form class="login card" method="post">
    <h1>Komanda Claude</h1>
    <input type="password" name="password" placeholder="Parol" autofocus required>
    <?php if ($error): ?><div class="err"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <button type="submit">Daxil ol</button>
  </form>
<?php else: ?>
  <header>
    <h1>Komanda Claude</h1>
    <div class="meta"><span id="conn">…</span><a href="?logout=1">Çıxış</a></div>
  </header>

  <h2>Kim nə edir</h2>
  <div class="grid" id="people"></div>

  <h2>Canlı axın</h2>
  <div class="filters" id="filters"></div>
  <div class="card feed" id="feed"></div>

<script>
const STATUS = { working: 'işləyir', waiting: 'səni gözləyir', idle: 'gözləyir', ended: 'bağlandı', offline: 'oflayn' };
const el = id => document.getElementById(id);
let data = null, filter = 'all';

function ago(ts, now) {
  const s = Math.max(0, now - ts);
  if (s < 10) return 'indi';
  if (s < 60) return s + ' san';
  if (s < 3600) return Math.floor(s / 60) + ' dəq';
  if (s < 86400) return Math.floor(s / 3600) + ' saat';
  return Math.floor(s / 86400) + ' gün';
}
function clock(ts) {
  return new Date(ts * 1000).toLocaleTimeString('az', { hour: '2-digit', minute: '2-digit' });
}
function eff(s, now) {              // 15 dəq-dən çox səssizlik = oflayn
  if (s.status === 'ended') return 'ended';
  return now - s.updated_at > 900 ? 'offline' : s.status;
}
function h(tag, cls, text) {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text != null) n.textContent = text;
  return n;
}

function render() {
  if (!data) return;
  const now = data.now;
  const people = el('people');
  people.replaceChildren();
  for (const u of data.users) {
    const mine = data.sessions.filter(s => s.user === u)
      .map(s => ({ ...s, st: eff(s, now) }))
      .filter(s => s.st !== 'ended' && s.st !== 'offline');
    const rank = { waiting: 3, working: 2, idle: 1 };
    const top = mine.reduce((a, s) => Math.max(a, rank[s.st] || 0), 0);
    const state = top === 3 ? 'waiting' : top === 2 ? 'working' : top === 1 ? 'idle' : 'offline';

    const card = h('div', 'card');
    const p = h('div', 'person');
    p.append(h('div', 'avatar', u[0].toUpperCase()));
    const info = h('div');
    info.append(h('div', 'pname', u));
    const ps = h('div', 'pstate');
    ps.append(h('span', 'dot ' + state), document.createTextNode(STATUS[state]));
    info.append(ps);
    p.append(info);
    card.append(p);

    if (!mine.length) card.append(h('div', 'empty', 'Hazırda aktiv sessiya yoxdur'));
    for (const s of mine) {
      const d = h('div', 'sess');
      const head = h('div', 'sproj');
      head.append(h('span', 'dot ' + s.st), document.createTextNode(s.project));
      d.append(head);
      if (s.last_prompt) d.append(h('div', 'sprompt', '“' + s.last_prompt + '”'));
      d.append(h('div', 'sline', s.last_summary));
      d.append(Object.assign(h('div', 'chips'), {}));
      const chips = d.lastChild;
      chips.append(h('span', null, ago(s.updated_at, now)), h('span', null, s.edits + ' dəyişiklik'), h('span', null, s.tool_count + ' əməliyyat'));
      card.append(d);
    }
    people.append(card);
  }

  const f = el('filters');
  f.replaceChildren();
  for (const name of ['all', ...data.users]) {
    const b = h('button', name === filter ? 'on' : '', name === 'all' ? 'Hamısı' : name);
    b.onclick = () => { filter = name; render(); };
    f.append(b);
  }
  const feed = el('feed');
  feed.replaceChildren();
  const evs = data.events.filter(e => filter === 'all' || e.user === filter);
  if (!evs.length) feed.append(h('div', 'empty', 'Hələ heç nə yoxdur'));
  for (const e of evs) {
    const r = h('div', 'row');
    r.append(h('div', 't', clock(e.created_at)), h('div', 'u', e.user));
    const s = h('div', 's', e.summary + ' ');
    s.append(h('small', null, '· ' + e.project));
    r.append(s);
    feed.append(r);
  }
}

async function tick() {
  if (document.hidden) return;
  try {
    const r = await fetch('feed.php', { cache: 'no-store' });
    if (r.status === 401) return location.reload();
    data = await r.json();
    el('conn').textContent = 'canlı · ' + clock(data.now);
    render();
  } catch (e) { el('conn').textContent = 'bağlantı yoxdur'; }
}
setInterval(tick, 3000);
document.addEventListener('visibilitychange', tick);
tick();
</script>
<?php endif; ?>
</div>
</body>
</html>
