<?php
require __DIR__ . '/db.php';
session_start();
if (empty($_SESSION['ok'])) {
    json_out(['error' => 'giriş lazımdır'], 401);
}
session_write_close();

$pdo = db();
$now = time();

$sessions = $pdo->prepare('SELECT user, session_id, project, status, last_prompt, last_summary, edits, tool_count, started_at, updated_at
    FROM sessions WHERE updated_at > ? ORDER BY updated_at DESC LIMIT 100');
$sessions->execute([$now - 86400]);

$events = $pdo->query('SELECT id, user, session_id, project, event, tool, summary, created_at
    FROM events ORDER BY id DESC LIMIT 80')->fetchAll();

json_out([
    'now' => $now,
    'users' => array_values(array_unique(array_values($config['users']))),
    'sessions' => $sessions->fetchAll(),
    'events' => $events,
]);
