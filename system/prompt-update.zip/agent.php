<?php
// Kompüterdəki agent: növbədən tapşırıq götürür və nəticəni qaytarır. Yalnız öz tokeninə aid tapşırıqlar.
require __DIR__ . '/db.php';

$user = token_user();
if ($user === null) {
    json_out(['error' => 'token yanlışdır'], 401);
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_out(['error' => 'POST lazımdır'], 405);
}
$act = (string)($_GET['a'] ?? '');
$pdo = db();
$now = time();

// ürək döyüntüsü
$has = $pdo->prepare('SELECT 1 FROM agents WHERE user = ?');
$has->execute([$user]);
if ($has->fetchColumn()) {
    $pdo->prepare('UPDATE agents SET last_seen = ? WHERE user = ?')->execute([$now, $user]);
} else {
    $pdo->prepare('INSERT INTO agents (user, last_seen) VALUES (?, ?)')->execute([$user, $now]);
}

if ($act === 'claim') {
    $pdo->prepare("UPDATE commands SET status = 'failed', result = ?, finished_at = ? WHERE user = ? AND status = 'running' AND started_at < ?")
        ->execute(['Vaxt bitdi: agent cavab vermədi', $now, $user, $now - 2400]);
    $pdo->beginTransaction();
    $q = $pdo->prepare("SELECT id, project, prompt FROM commands WHERE user = ? AND status = 'queued' ORDER BY id ASC LIMIT 1");
    $q->execute([$user]);
    $row = $q->fetch();
    if (!$row) {
        $pdo->commit();
        json_out(['none' => true]);
    }
    $u = $pdo->prepare("UPDATE commands SET status = 'running', started_at = ? WHERE id = ? AND status = 'queued'");
    $u->execute([$now, $row['id']]);
    $pdo->commit();
    if ($u->rowCount() !== 1) {
        json_out(['none' => true]);
    }
    json_out(['id' => (int)$row['id'], 'project' => $row['project'], 'prompt' => $row['prompt']]);
}

if ($act === 'finish') {
    $in = json_decode(file_get_contents('php://input', false, null, 0, 65536) ?: '', true);
    if (!is_array($in)) {
        json_out(['error' => 'yanlış sorğu'], 400);
    }
    $status = ($in['status'] ?? '') === 'done' ? 'done' : 'failed';
    $result = mb_substr((string)($in['result'] ?? ''), 0, 8000);
    $st = $pdo->prepare("UPDATE commands SET status = ?, result = ?, finished_at = ? WHERE id = ? AND user = ? AND status = 'running'");
    $st->execute([$status, $result, $now, (int)($in['id'] ?? 0), $user]);
    json_out(['ok' => $st->rowCount() === 1]);
}

if ($act === 'ping') {
    json_out(['ok' => true, 'user' => $user]);
}

json_out(['error' => 'naməlum əməliyyat'], 400);
