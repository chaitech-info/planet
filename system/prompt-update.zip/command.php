<?php
// Brauzer → növbə: istifadəçi öz tokeni ilə prompt göndərir. Yalnız öz maşınına.
require __DIR__ . '/db.php';

$user = token_user();
if ($user === null) {
    json_out(['error' => 'token yanlışdır'], 401);
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_out(['error' => 'POST lazımdır'], 405);
}
$in = json_decode(file_get_contents('php://input', false, null, 0, 20000) ?: '', true);
if (!is_array($in)) {
    json_out(['error' => 'yanlış sorğu'], 400);
}
$act = (string)($in['action'] ?? '');
$pdo = db();
$now = time();

if ($act === 'whoami') {
    json_out(['user' => $user]);
}

if ($act === 'send') {
    $project = trim((string)($in['project'] ?? ''));
    $prompt = trim((string)($in['prompt'] ?? ''));
    if ($project === '' || mb_strlen($project) > 128) {
        json_out(['error' => 'proyekt adı yanlışdır'], 400);
    }
    if ($prompt === '' || mb_strlen($prompt) > 4000) {
        json_out(['error' => 'prompt 1-4000 simvol olmalıdır'], 400);
    }
    $c = $pdo->prepare("SELECT COUNT(*) FROM commands WHERE user = ? AND status IN ('queued','running')");
    $c->execute([$user]);
    if ((int)$c->fetchColumn() >= 5) {
        json_out(['error' => 'növbədə artıq 5 tapşırıq var, gözlə'], 429);
    }
    $pdo->prepare("INSERT INTO commands (user, project, prompt, status, result, created_at, started_at, finished_at) VALUES (?,?,?,?,?,?,?,?)")
        ->execute([$user, $project, $prompt, 'queued', '', $now, 0, 0]);
    json_out(['ok' => true, 'id' => (int)$pdo->lastInsertId()]);
}

if ($act === 'cancel') {
    $st = $pdo->prepare("UPDATE commands SET status = 'canceled', finished_at = ? WHERE id = ? AND user = ? AND status = 'queued'");
    $st->execute([$now, (int)($in['id'] ?? 0), $user]);
    json_out(['ok' => $st->rowCount() === 1]);
}

json_out(['error' => 'naməlum əməliyyat'], 400);
