<?php
require __DIR__ . '/db.php';
session_start();
if (empty($_SESSION['ok'])) {
    json_out(['error' => 'giriş lazımdır'], 401);
}
session_write_close();

$pdo = db();
$now = time();

$sessions = $pdo->prepare('SELECT user, session_id, project, status, last_prompt, last_summary, edits, tool_count, started_at, updated_at
    FROM sessions WHERE updated_at > ? ORDER BY updated_at DESC LIMIT 100');
$sessions->execute([$now - 86400]);

$onlyProject = isset($_GET['project']) ? substr((string)$_GET['project'], 0, 128) : '';
if ($onlyProject !== '') {
    $ev = $pdo->prepare('SELECT id, user, session_id, project, event, tool, summary, created_at
        FROM events WHERE project = ? ORDER BY id DESC LIMIT 60');
    $ev->execute([$onlyProject]);
    $events = $ev->fetchAll();
} else {
    $events = $pdo->query('SELECT id, user, session_id, project, event, tool, summary, created_at
        FROM events ORDER BY id DESC LIMIT 80')->fetchAll();
}

$projects = $pdo->prepare('SELECT project, user, COUNT(*) AS sessions, SUM(edits) AS edits, SUM(tool_count) AS tools, MAX(updated_at) AS last_at
    FROM sessions WHERE updated_at > ? GROUP BY project, user');
$projects->execute([$now - 30 * 86400]);

$cmds = $pdo->query('SELECT id, user, project, prompt, status, result, created_at, started_at, finished_at
    FROM commands ORDER BY id DESC LIMIT 40')->fetchAll();
foreach ($cmds as &$c) {
    $c['result'] = mb_substr($c['result'], 0, 3000);
}
unset($c);
$agents = $pdo->query('SELECT user, last_seen FROM agents')->fetchAll();

json_out([
    'now' => $now,
    'commands' => $cmds,
    'agents' => $agents,
    'users' => array_values(array_unique(array_values($config['users']))),
    'sessions' => $sessions->fetchAll(),
    'projects' => $projects->fetchAll(),
    'events' => $events,
]);
