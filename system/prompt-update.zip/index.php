<?php
require __DIR__ . '/db.php';
session_start();
$error = '';
if (isset($_GET['logout'])) {
    $_SESSION = [];
    session_destroy();
    header('Location: ./');
    exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    usleep(400000);
    if (hash_equals($config['dashboard_password'], (string)($_POST['password'] ?? ''))) {
        session_regenerate_id(true);
        $_SESSION['ok'] = true;
        header('Location: ./');
        exit;
    }
    $error = 'Parol yanlışdır';
}
$authed = !empty($_SESSION['ok']);
?><!doctype html>
<html lang="az">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex">
<title>Komanda Claude</title>
<style>
:root {
  --ease-out: cubic-bezier(0.23, 1, 0.32, 1);
  --bg: #f4f3ef; --card: rgba(255,255,255,.78); --text: #1b1b19; --muted: #6b6b64; --line: rgba(0,0,0,.09);
  --work: #d97706; --wait: #dc2626; --idle: #16a34a; --off: #a3a39c;
  --accent: #c4552d; --violet: #6d5bd0;
  --glow1: rgba(217,119,6,.20); --glow2: rgba(109,91,208,.18); --glow3: rgba(22,163,74,.14);
  --shadow: 0 1px 2px rgba(0,0,0,.05), 0 8px 24px rgba(0,0,0,.05);
}
@media (prefers-color-scheme: dark) {
  :root {
    --bg: #0f0f12; --card: rgba(30,30,36,.72); --text: #ececf1; --muted: #9a9aa6; --line: rgba(255,255,255,.09);
    --work: #fbbf24; --wait: #f87171; --idle: #4ade80; --off: #6b6b78;
    --accent: #f08a5d; --violet: #9d8cff;
    --glow1: rgba(240,138,93,.20); --glow2: rgba(157,140,255,.20); --glow3: rgba(74,222,128,.12);
    --shadow: 0 1px 2px rgba(0,0,0,.4), 0 12px 32px rgba(0,0,0,.35);
  }
}
* { box-sizing: border-box; }
html { background: var(--bg); }
body { margin: 0; color: var(--text); font: 15px/1.45 system-ui, -apple-system, "Segoe UI", sans-serif; min-height: 100vh; overflow-x: hidden; }

/* Fon: yavaş sürüşən işıq ləkələri (yalnız transform) */
body::before {
  content: ""; position: fixed; inset: -25%; z-index: -1; pointer-events: none; will-change: transform;
  background:
    radial-gradient(38% 38% at 18% 22%, var(--glow1), transparent 70%),
    radial-gradient(34% 34% at 82% 18%, var(--glow2), transparent 70%),
    radial-gradient(42% 42% at 62% 86%, var(--glow3), transparent 70%);
  animation: drift 26s ease-in-out infinite alternate;
}
@keyframes drift {
  from { transform: translate3d(-3%, -2%, 0) rotate(0deg) scale(1); }
  to   { transform: translate3d(3%, 3%, 0) rotate(7deg) scale(1.06); }
}

.wrap { max-width: 1120px; margin: 0 auto; padding: 22px 16px 56px; }
header { display: flex; align-items: center; justify-content: space-between; gap: 12px; margin-bottom: 22px; }
.brand { display: flex; align-items: center; gap: 12px; }
.logo { position: relative; width: 34px; height: 34px; border-radius: 10px; background: linear-gradient(135deg, var(--accent), var(--violet)); display: grid; place-items: center; color: #fff; font-weight: 700; }
.logo::after { content: ""; position: absolute; inset: 0; border-radius: inherit; border: 2px solid var(--accent); opacity: 0; animation: ping 2.4s var(--ease-out) infinite; }
h1 { font-size: 19px; margin: 0; letter-spacing: -.01em; }
h2 { font-size: 12px; text-transform: uppercase; letter-spacing: .09em; color: var(--muted); margin: 30px 0 12px; display: flex; align-items: center; gap: 10px; font-weight: 600; }
h2 .count { background: var(--line); color: var(--text); border-radius: 999px; padding: 1px 8px; font-size: 11px; }
.meta { display: flex; gap: 14px; align-items: center; color: var(--muted); font-size: 13px; }
.live { display: inline-flex; align-items: center; gap: 7px; padding: 4px 11px; border-radius: 999px; background: var(--card); border: 1px solid var(--line); }
.live .dot { margin: 0; }
.live[data-off] .dot { background: var(--wait); }
.live[data-off] .dot::after { display: none; }
a { color: var(--muted); }

/* Canlı nöqtə */
.dot { position: relative; display: inline-block; width: 8px; height: 8px; border-radius: 50%; background: var(--off); flex: none; }
.dot::after { content: ""; position: absolute; inset: 0; border-radius: 50%; background: inherit; opacity: 0; }
.dot.working, .dot.live { background: var(--work); }
.live .dot { background: var(--idle); }
.dot.waiting { background: var(--wait); }
.dot.idle { background: var(--idle); }
.dot.working::after, .dot.waiting::after, .live .dot::after { animation: ping 1.8s var(--ease-out) infinite; }
@keyframes ping { 0% { transform: scale(1); opacity: .55; } 80%, 100% { transform: scale(2.8); opacity: 0; } }

/* Statistika */
.stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 12px; }
.stat { background: var(--card); border: 1px solid var(--line); border-radius: 14px; padding: 12px 16px; box-shadow: var(--shadow); backdrop-filter: blur(10px); }
.stat b { display: block; font-size: 26px; line-height: 1.1; font-variant-numeric: tabular-nums; letter-spacing: -.02em; transform-origin: left center; }
.stat span { color: var(--muted); font-size: 12.5px; }
.stat b.bump { animation: bump .45s var(--ease-out); }
@keyframes bump { 0% { transform: scale(1.18); color: var(--accent); } 100% { transform: scale(1); } }

.grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 14px; }
.card { position: relative; background: var(--card); border: 1px solid var(--line); border-radius: 16px; padding: 16px; box-shadow: var(--shadow); backdrop-filter: blur(10px); }
.enter { animation: enter .45s var(--ease-out) backwards; animation-delay: calc(var(--i, 0) * 45ms); }
@keyframes enter { from { opacity: 0; transform: translateY(10px) scale(.98); } to { opacity: 1; transform: none; } }
@media (hover: hover) and (pointer: fine) {
  .card { transition: transform .2s var(--ease-out); }
  .card:hover { transform: translateY(-2px); }
}

/* Adam kartı */
.person { display: flex; align-items: center; gap: 12px; margin-bottom: 4px; }
.avatar { position: relative; width: 40px; height: 40px; border-radius: 50%; display: grid; place-items: center; color: #fff; font-weight: 700; font-size: 16px; flex: none; }
.avatar .ring { position: absolute; inset: -5px; border-radius: 50%; opacity: 0;
  background: conic-gradient(from 0deg, var(--work), transparent 65%, var(--work));
  -webkit-mask: radial-gradient(farthest-side, transparent calc(100% - 3px), #000 calc(100% - 2px));
          mask: radial-gradient(farthest-side, transparent calc(100% - 3px), #000 calc(100% - 2px)); }
[data-st="working"] > .person .ring, .stack .avatar[data-st="working"] .ring { opacity: 1; animation: spin 1.6s linear infinite; }
.stack .avatar[data-st="waiting"] .ring { opacity: 1; background: conic-gradient(var(--wait), var(--wait)); animation: breathe 1.4s ease-in-out infinite; }
[data-st="waiting"] > .person .ring { opacity: 1; background: conic-gradient(var(--wait), var(--wait)); animation: breathe 1.4s ease-in-out infinite; }
[data-st="idle"] > .person .ring { opacity: .55; background: conic-gradient(var(--idle), var(--idle)); }
@keyframes spin { to { transform: rotate(360deg); } }
@keyframes breathe { 0%, 100% { opacity: .25; transform: scale(.98); } 50% { opacity: 1; transform: scale(1.04); } }
.pname { font-weight: 650; font-size: 16px; }
.chip { display: inline-flex; align-items: center; gap: 7px; font-size: 12.5px; color: var(--muted); }
.empty { color: var(--muted); font-size: 13.5px; padding: 10px 0 2px; }

.sess { border-top: 1px solid var(--line); margin-top: 12px; padding-top: 12px; }
.shead { display: flex; align-items: center; gap: 8px; font-weight: 600; font-size: 14px; }
.sprompt { margin: 6px 0 2px; font-size: 13.5px; overflow-wrap: anywhere; }
.sline { color: var(--muted); font-size: 13px; overflow-wrap: anywhere; display: flex; gap: 6px; align-items: baseline; }
.sline span.t { min-width: 0; }
.chips { display: flex; gap: 12px; margin-top: 8px; font-size: 12px; color: var(--muted); font-variant-numeric: tabular-nums; }

/* Axan progress zolağı + yazma nöqtələri (iş gedəndə) */
.bar { position: relative; height: 3px; margin-top: 10px; border-radius: 3px; overflow: hidden; background: var(--line); opacity: 0; }
.bar::after { content: ""; position: absolute; inset: 0 auto 0 0; width: 38%; border-radius: inherit;
  background: linear-gradient(90deg, transparent, var(--work), var(--accent), transparent); animation: slide 1.5s linear infinite; }
@keyframes slide { from { transform: translateX(-110%); } to { transform: translateX(270%); } }
.sess[data-st="working"] .bar { opacity: 1; }
.typing { display: none; gap: 3px; align-items: center; flex: none; transform: translateY(-1px); }
.typing i { width: 4px; height: 4px; border-radius: 50%; background: var(--work); animation: hop 1s ease-in-out infinite; }
.typing i:nth-child(2) { animation-delay: .15s; } .typing i:nth-child(3) { animation-delay: .3s; }
@keyframes hop { 0%, 60%, 100% { transform: translateY(0); opacity: .45; } 30% { transform: translateY(-4px); opacity: 1; } }
.sess[data-st="working"] .typing { display: inline-flex; }

/* Proyektlər */
.filters { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 12px; }
.filters button { border: 1px solid var(--line); background: var(--card); color: var(--text); border-radius: 999px; padding: 5px 14px; font: inherit; font-size: 13px; cursor: pointer; transition: background-color .15s ease, color .15s ease; }
.filters button:active { transform: scale(.97); }
.filters button.on { background: var(--accent); border-color: var(--accent); color: #fff; }
.proj::after { content: ""; position: absolute; inset: -1px; border-radius: inherit; border: 1.5px solid var(--work); opacity: 0; pointer-events: none; }
.proj[data-st="working"]::after { animation: glow 2.4s ease-in-out infinite; }
.proj[data-st="waiting"]::after { border-color: var(--wait); animation: glow 1.4s ease-in-out infinite; }
@keyframes glow { 0%, 100% { opacity: .15; } 50% { opacity: .9; } }
.pjhead { display: flex; align-items: center; justify-content: space-between; gap: 10px; }
.pjname { font-weight: 650; font-size: 16px; overflow-wrap: anywhere; }
.pjtitle { display: flex; align-items: center; gap: 9px; min-width: 0; }
.pjsum { color: var(--muted); font-size: 13px; margin: 8px 0 12px; min-height: 19px; overflow-wrap: anywhere; }
.pjfoot { display: flex; align-items: center; justify-content: space-between; gap: 10px; }
.stack { display: flex; }
.stack .avatar { width: 26px; height: 26px; font-size: 11px; margin-left: -7px; border: 2px solid var(--bg); }
.stack .avatar:first-child { margin-left: 0; }
.stack .avatar .ring { inset: -4px; }
.pjnums { display: flex; gap: 12px; font-size: 12px; color: var(--muted); font-variant-numeric: tabular-nums; }

/* Canlı axın */
.feed { padding: 6px 16px; }
.row { position: relative; display: grid; grid-template-columns: 62px 1fr; gap: 10px; padding: 10px 0; border-top: 1px solid var(--line); font-size: 13.5px; }
.row:first-child { border-top: 0; }
.row .t { color: var(--muted); font-variant-numeric: tabular-nums; font-size: 12.5px; padding-top: 1px; }
.row .s { overflow-wrap: anywhere; }
.row .u { display: inline-block; font-weight: 650; margin-right: 6px; }
.row small { color: var(--muted); }
.row .k { display: inline-block; width: 7px; height: 7px; border-radius: 50%; margin-right: 7px; background: var(--muted); }
.row.k-prompt .k { background: var(--accent); } .row.k-edit .k { background: var(--violet); }
.row.k-stop .k { background: var(--idle); } .row.k-wait .k { background: var(--wait); }
.row.fresh::before { content: ""; position: absolute; inset: 0 -16px; background: var(--accent); opacity: 0; pointer-events: none; animation: flash 1.8s var(--ease-out); }
@keyframes flash { 0% { opacity: .16; } 100% { opacity: 0; } }
.row.enter { animation: rowin .32s var(--ease-out) backwards; animation-delay: calc(var(--i, 0) * 35ms); }
@keyframes rowin { from { opacity: 0; transform: translateX(-8px); } to { opacity: 1; transform: none; } }

/* ===== Naviqasiya ===== */
.tabs { display: flex; gap: 4px; padding: 4px; border-radius: 999px; background: var(--card); border: 1px solid var(--line); }
.tabs a { padding: 5px 16px; border-radius: 999px; color: var(--muted); text-decoration: none; font-size: 13.5px; font-weight: 600; transition: background-color .15s ease, color .15s ease; }
.tabs a.on { background: var(--accent); color: #fff; }
header { flex-wrap: wrap; }
.gbtn { border: 1px solid var(--line); background: var(--card); color: var(--text); border-radius: 999px; padding: 6px 14px; font: inherit; font-size: 13px; cursor: pointer; transition: transform .15s var(--ease-out); }
.gbtn:active { transform: scale(.97); }
.gbtn[hidden] { display: none; }
.ptop { display: flex; gap: 8px; align-items: center; margin-bottom: 12px; flex-wrap: wrap; }
.ptop .sp { flex: 1; }

/* ===== Kainat (həmişə tünd) ===== */
:root { --ease-io: cubic-bezier(0.77, 0, 0.175, 1); }
.space { position: relative; overflow: hidden; isolation: isolate; border-radius: 20px; border: 1px solid rgba(255,255,255,.08);
  background: radial-gradient(120% 90% at 50% 0%, #14172e 0%, #080914 55%, #03030a 100%); color: #e9e9f3; box-shadow: var(--shadow); }
.skyz { position: absolute; inset: 0; z-index: -1; pointer-events: none; transition: transform .6s var(--ease-io), opacity .5s ease; }
.nebula { position: absolute; inset: -20%; will-change: transform;
  background: radial-gradient(35% 30% at 25% 35%, rgba(109,91,208,.24), transparent 70%), radial-gradient(30% 28% at 78% 62%, rgba(217,90,120,.15), transparent 70%), radial-gradient(26% 24% at 55% 12%, rgba(60,160,220,.12), transparent 70%);
  animation: drift 40s ease-in-out infinite alternate; }
.stars { position: absolute; left: 0; top: 0; border-radius: 50%; will-change: opacity, translate; }
.stars.s1 { width: 1px; height: 1px; animation: twinkle 5s ease-in-out infinite alternate, sdrift 70s ease-in-out infinite alternate; }
.stars.s2 { width: 2px; height: 2px; animation: twinkle 7s -2s ease-in-out infinite alternate, sdrift 50s ease-in-out infinite alternate; }
.stars.s3 { width: 3px; height: 3px; animation: twinkle 4s -1s ease-in-out infinite alternate, sdrift 36s ease-in-out infinite alternate; }
@keyframes twinkle { from { opacity: .35; } to { opacity: 1; } }
@keyframes sdrift { from { translate: 0 0; } to { translate: -34px -22px; } }
.shoot { position: absolute; left: var(--sx); top: var(--sy); width: 110px; height: 1.5px; opacity: 0; transform: rotate(24deg);
  background: linear-gradient(90deg, transparent, #fff); animation: shoot 12s linear infinite; animation-delay: var(--sd); }
@keyframes shoot { 0% { opacity: 0; transform: rotate(24deg) translateX(0); } 2% { opacity: 1; } 8% { opacity: 0; transform: rotate(24deg) translateX(460px); } 100% { opacity: 0; } }

.hud { position: absolute; left: 18px; top: 14px; z-index: 2; display: flex; gap: 14px; font-size: 12.5px; color: rgba(233,233,243,.72); }
.hud span:first-child { font-weight: 600; color: #fff; }
.scene { position: relative; width: min(100%, 74vh, 720px); aspect-ratio: 1 / .8; margin: 6px auto 0; container-type: inline-size; touch-action: pan-y; cursor: grab; user-select: none; -webkit-user-select: none; }
.scene:active { cursor: grabbing; }
.cam { position: absolute; inset: 0; perspective: 195cqw; perspective-origin: 50% 45%; }
.rig { position: absolute; left: 0; top: 50%; width: 100%; aspect-ratio: 1; margin-top: -50%; transform-style: preserve-3d;
  transform: rotateX(calc(var(--tx, 58) * 1deg)) rotateZ(calc(var(--rz, -18) * 1deg)); }
.rig::before { content: ""; position: absolute; inset: -4%; border-radius: 50%; pointer-events: none; transform: translateZ(-3px);
  background: radial-gradient(closest-side, rgba(255,170,80,.15), rgba(120,100,220,.07) 55%, transparent 72%); }
.rig::after { content: ""; position: absolute; inset: 6%; border-radius: 50%; pointer-events: none; transform: translateZ(-2px);
  background: conic-gradient(rgba(160,140,255,0), rgba(160,140,255,.12), rgba(160,140,255,0) 30%, rgba(255,160,100,.1) 55%, rgba(255,160,100,0) 80%);
  -webkit-mask: radial-gradient(closest-side, transparent 50%, #000 70%, transparent 100%); mask: radial-gradient(closest-side, transparent 50%, #000 70%, transparent 100%);
  animation: spinr 90s linear infinite; }
@keyframes spinr { to { rotate: 360deg; } }
.skyz { translate: calc(var(--rz, -18) * -.6px) calc((var(--tx, 58) - 58) * -.5px); }
.space.warping .scene { transform: scale(3.4); opacity: 0; transition: transform .6s var(--ease-io), opacity .4s ease .15s; }
.space.warping .skyz { transform: scale(1.7); opacity: .45; }
/* Tam ekran Kainat */
body.v-space .wrap { max-width: none; padding: 12px 14px 14px; }
#space { --H: calc(100vh - 116px); height: var(--H); min-height: 460px; display: flex; flex-direction: column; justify-content: center; }
#space:fullscreen { --H: 100vh; height: 100vh; border-radius: 0; border: 0; }
#space .scene { width: min(100%, calc((var(--H) - 90px) * 1.25)); max-width: none; margin: 0 auto; }
#space .travel { position: absolute; left: 0; right: 0; bottom: 0; padding-bottom: 14px; }
#space:not(.gl) .zbtns { display: none; }
.zbtns { position: absolute; right: 14px; top: 54px; z-index: 3; display: grid; gap: 6px; }
.zbtns button { width: 36px; height: 36px; border-radius: 10px; border: 1px solid rgba(255,255,255,.16); background: rgba(255,255,255,.07); color: #e9e9f3; font-size: 20px; line-height: 1; cursor: pointer; transition: background-color .15s ease, transform .15s var(--ease-out); }
.zbtns button:active { transform: scale(.94); }
@media (hover: hover) and (pointer: fine) { .zbtns button:hover { background: rgba(255,255,255,.15); } }
.fsbtn { position: absolute; right: 14px; top: 10px; z-index: 3; width: 36px; height: 36px; border-radius: 10px; border: 1px solid rgba(255,255,255,.16); background: rgba(255,255,255,.07); color: #e9e9f3; font-size: 18px; line-height: 1; cursor: pointer; transition: background-color .15s ease, transform .15s var(--ease-out); }
.fsbtn:active { transform: scale(.94); }
@media (hover: hover) and (pointer: fine) { .fsbtn:hover { background: rgba(255,255,255,.15); } }
@keyframes arrive { from { opacity: 0; transform: scale(1.35); } to { opacity: 1; transform: none; } }
.scene.arrive { animation: arrive .6s var(--ease-out); }
#orbits { position: absolute; inset: 0; transform-style: preserve-3d; }

.sun { position: absolute; inset: 0; margin: auto; width: 9cqw; height: 9cqw; border-radius: 50%; transform: rotateZ(calc(var(--rz, -18) * -1deg)) rotateX(calc(var(--tx, 58) * -1deg));
  background: radial-gradient(circle at 40% 35%, #fff6c8, #ffb347 45%, #ff7a3d 100%); box-shadow: 0 0 6cqw 1cqw rgba(255,150,60,.42); }
.sun::before { content: ""; position: absolute; inset: -38%; border-radius: 50%;
  background: conic-gradient(rgba(255,170,70,0), rgba(255,170,70,.4), rgba(255,170,70,0) 40%, rgba(255,120,60,.32) 70%, rgba(255,170,70,0));
  -webkit-mask: radial-gradient(closest-side, transparent 52%, #000 56%, transparent 100%); mask: radial-gradient(closest-side, transparent 52%, #000 56%, transparent 100%);
  animation: spin 16s linear infinite; }
.sun::after { content: ""; position: absolute; inset: -6%; border-radius: 50%; border: 2px solid rgba(255,190,100,.55); opacity: 0; animation: sunping 3.4s var(--ease-out) infinite; }
@keyframes sunping { 0% { transform: scale(1); opacity: .55; } 100% { transform: scale(1.9); opacity: 0; } }
.sunlbl { position: absolute; top: 112%; left: 50%; transform: translateX(-50%); font-size: clamp(10px, 1.7cqw, 12px); letter-spacing: .12em; text-transform: uppercase; color: rgba(255,214,160,.75); white-space: nowrap; }

.orbit { position: absolute; inset: calc(50% - var(--d, 50) * .5%); width: calc(var(--d, 50) * 1%); height: calc(var(--d, 50) * 1%);
  pointer-events: none; transform-style: preserve-3d; animation: spin var(--T, 120s) linear infinite; animation-delay: var(--dl, 0s); }
.orbit::before { content: ""; position: absolute; inset: 0; border-radius: 50%; border: 1px dashed rgba(255,255,255,.09); }
.slot { position: absolute; left: 50%; top: 0; width: 0; height: 0; transform-style: preserve-3d; animation: spin-rev var(--T, 120s) linear infinite; animation-delay: var(--dl, 0s); }
@keyframes spin-rev { to { transform: rotate(-360deg); } }
.scene:has(.pbox:hover) .orbit, .scene:has(.pbox:hover) .slot { animation-play-state: paused; }

.pbox { position: absolute; left: 0; top: 0; width: calc(var(--s, 9) * 1cqw); aspect-ratio: 1; transform-style: preserve-3d;
  --bb: translateZ(calc(var(--z, 0) * 1cqw)) translate(-50%, -50%) rotateZ(calc(var(--rz, -18) * -1deg)) rotateX(calc(var(--tx, 58) * -1deg));
  transform: var(--bb);
  border: 0; background: none; padding: 0; color: inherit; font: inherit; cursor: pointer; pointer-events: auto; transition: transform .25s var(--ease-out); }
.pbox:focus-visible { outline: 2px solid #fff; outline-offset: 6px; border-radius: 50%; }
@media (hover: hover) and (pointer: fine) { .pbox:hover { transform: var(--bb) scale(1.12); } }
.pbox:active { transform: var(--bb) scale(.97); }
.pbox.pop { animation: pop .6s var(--ease-out) backwards; animation-delay: calc(var(--i, 0) * 80ms); }
@keyframes pop { from { opacity: 0; scale: .3; } to { opacity: 1; scale: 1; } }
.plabel { position: absolute; top: 100%; left: 50%; transform: translateX(-50%); margin-top: .5em; text-align: center; white-space: nowrap; line-height: 1.25; pointer-events: none; font-size: clamp(10px, 1.8cqw, 13px); text-shadow: 0 1px 6px rgba(0,0,0,.8); }
.plabel b { display: block; font-weight: 650; }
.plabel span { color: rgba(233,233,243,.62); font-size: .88em; }
.pbox[data-st="working"] .plabel span { color: #fbbf24; }
.pbox[data-st="waiting"] .plabel span { color: #f87171; }

/* Planet */
.planet { position: relative; width: 100%; aspect-ratio: 1; border-radius: 50%; transform-style: preserve-3d; }
.planet .aura { position: absolute; inset: -34%; border-radius: 50%; opacity: .26; pointer-events: none;
  background: radial-gradient(closest-side, hsl(var(--h) 90% 62% / .55), transparent); }
.planet .body { position: absolute; inset: 0; border-radius: 50%; overflow: hidden;
  background: radial-gradient(circle at 32% 28%, hsl(var(--h) 75% 72%), hsl(var(--h) 60% 42%) 52%, hsl(var(--h) 55% 15%)); }
.planet .body::after { content: ""; position: absolute; inset: 0; border-radius: 50%; background: radial-gradient(circle at 30% 28%, transparent 38%, rgba(0,0,0,.6) 100%); }
.planet .surf { position: absolute; top: 0; left: 0; width: 200%; height: 100%; background-size: 50% 100%; background-repeat: repeat-x; will-change: transform;
  background-image: radial-gradient(ellipse 30% 20% at 22% 30%, hsl(var(--h) 85% 85% / .38), transparent), radial-gradient(ellipse 24% 17% at 64% 64%, hsl(var(--h) 45% 14% / .42), transparent), radial-gradient(ellipse 16% 11% at 82% 22%, hsl(var(--h) 80% 82% / .3), transparent), radial-gradient(ellipse 20% 12% at 40% 82%, hsl(var(--h) 70% 25% / .35), transparent);
  animation: surf 38s linear infinite; }
@keyframes surf { to { transform: translateX(-50%); } }
.planet .ringd { position: absolute; left: -38%; right: -38%; top: 38%; bottom: 38%; border-radius: 50%; border: 3px solid hsl(var(--h) 55% 78% / .45); transform: rotate(-18deg); pointer-events: none; }
.moons { position: absolute; inset: 0; pointer-events: none; transform-style: preserve-3d; transform: rotateX(72deg); }
.mo { position: absolute; inset: calc(var(--r, -22) * 1%); transform-style: preserve-3d; animation: spin var(--mp, 14s) linear infinite; animation-delay: var(--d, 0s); }
.mm { position: absolute; left: 50%; top: 0; width: 9%; aspect-ratio: 1; margin: -4.5% 0 0 -4.5%; transform-style: preserve-3d; animation: spin-rev var(--mp, 14s) linear infinite; animation-delay: var(--d, 0s); }
.mo[data-st="working"] { --mp: 5s; }
.mo[data-st="offline"], .mo[data-st="ended"] { opacity: .35; --mp: 26s; }
.moon { position: absolute; inset: 0; border-radius: 50%; transform: rotateX(-72deg); box-shadow: 0 0 8px currentColor; }
.pbox[data-st="working"] .aura, .hero[data-st="working"] .aura { opacity: .6; animation: aura 2.2s ease-in-out infinite; }
.pbox[data-st="waiting"] .aura, .hero[data-st="waiting"] .aura { background: radial-gradient(closest-side, rgba(248,113,113,.7), transparent); opacity: .6; animation: aura 1.3s ease-in-out infinite; }
.pbox[data-st="idle"] .aura, .hero[data-st="idle"] .aura { opacity: .34; }
.pbox[data-st="offline"] .body, .hero[data-st="offline"] .body { filter: saturate(.35) brightness(.75); }
@keyframes aura { 0%, 100% { transform: scale(.95); opacity: .3; } 50% { transform: scale(1.16); opacity: .85; } }

.travel { display: flex; gap: 8px; flex-wrap: wrap; justify-content: center; padding: 6px 14px 16px; position: relative; z-index: 2; }
.travel button { display: inline-flex; align-items: center; gap: 8px; border: 1px solid rgba(255,255,255,.14); background: rgba(255,255,255,.06); color: #e9e9f3; border-radius: 999px; padding: 5px 13px; font: inherit; font-size: 13px; cursor: pointer; transition: background-color .15s ease, transform .15s var(--ease-out); }
.travel button:active { transform: scale(.97); }
@media (hover: hover) and (pointer: fine) { .travel button:hover { background: rgba(255,255,255,.14); } }
.tdot { width: 9px; height: 9px; border-radius: 50%; background: hsl(var(--h) 70% 55%); }
.sempty { text-align: center; padding: 0 24px 28px; color: rgba(233,233,243,.65); font-size: 14px; }
.space .enter { animation-name: enter; }

/* Planet səhifəsi */
.hero { display: flex; align-items: center; gap: 36px; flex-wrap: wrap; padding: 26px 32px; min-height: 290px; }
.hplanet { position: relative; width: 170px; height: 170px; margin: 22px 34px; flex: none; transform-style: preserve-3d; }
.hplanet.landing { animation: landing .8s var(--ease-out) backwards; }
@keyframes landing { from { opacity: 0; transform: translateY(24px) scale(.5); } to { opacity: 1; transform: none; } }
.hinfo { flex: 1; min-width: 240px; }
.ptitle { font-size: 28px; font-weight: 700; letter-spacing: -.02em; overflow-wrap: anywhere; }
.hinfo .chip { color: rgba(233,233,243,.75); margin: 4px 0 14px; font-size: 13.5px; }
.hstats { display: flex; gap: 22px; flex-wrap: wrap; margin-bottom: 16px; }
.hstats div { min-width: 70px; }
.hstats b { display: block; font-size: 22px; font-variant-numeric: tabular-nums; }
.hstats span { font-size: 12px; color: rgba(233,233,243,.6); }
.crew { display: flex; gap: 14px; flex-wrap: wrap; }
.crewm { display: flex; align-items: center; gap: 8px; font-size: 13px; }
.crewm .avatar { width: 28px; height: 28px; font-size: 12px; }
.crewm[data-st="offline"], .crewm[data-st="ended"] { opacity: .5; }
.card.sess { margin-top: 0; padding: 16px; }
.card.sess .shead { gap: 10px; }
.card.sess .shead .avatar { width: 30px; height: 30px; font-size: 13px; }
.card.sess .st { margin-left: auto; font-size: 12.5px; font-weight: 500; color: var(--muted); display: inline-flex; align-items: center; gap: 7px; }
.card.sess[data-st="offline"], .card.sess[data-st="ended"] { opacity: .6; }
.pcard[data-st="working"] .avatar .ring, .crewm[data-st="working"] .avatar .ring { opacity: 1; animation: spin 1.6s linear infinite; }
.pcard[data-st="waiting"] .avatar .ring, .crewm[data-st="waiting"] .avatar .ring { opacity: 1; background: conic-gradient(var(--wait), var(--wait)); animation: breathe 1.4s ease-in-out infinite; }
.pcard[data-st="idle"] .avatar .ring, .crewm[data-st="idle"] .avatar .ring { opacity: .55; background: conic-gradient(var(--idle), var(--idle)); }
.proj { cursor: pointer; }
@media (max-width: 520px) { .hero { padding: 16px; gap: 8px; } .hplanet { margin: 18px auto; } }

/* ===== WebGL qatı və canlı panel (dock) ===== */
#space.gl .scene, #space.gl .skyz { display: none; }
#space.gl .dock { -webkit-backdrop-filter: none; backdrop-filter: none; background: rgba(9,10,20,.9); }
body.v-space::before { display: none; }
.glcanvas { position: absolute; inset: 0; width: 100%; height: 100%; display: block; z-index: 0; touch-action: none; cursor: grab; outline: none; }
.glbls { position: absolute; inset: 0; z-index: 1; pointer-events: none; overflow: hidden; }
.glabel { position: absolute; left: 0; top: 0; pointer-events: auto; background: none; border: 0; padding: 4px 8px; color: #e9e9f3; font: inherit; font-size: 13px; text-align: center; line-height: 1.25; white-space: nowrap; cursor: pointer; text-shadow: 0 1px 8px #000, 0 0 2px #000; will-change: transform; transition: opacity .3s ease; }
.glabel b { display: block; font-weight: 650; transition: transform .2s var(--ease-out); }
.glabel span { color: rgba(233,233,243,.62); font-size: 12px; }
.glabel[data-st="working"] span { color: #fbbf24; } .glabel[data-st="waiting"] span { color: #f87171; }
.glabel.hov b { transform: scale(1.12); }
.glabel.sunl { pointer-events: none; font-size: 11px; letter-spacing: .14em; text-transform: uppercase; color: rgba(255,214,160,.8); }
#space .hud, #space .travel, #space .fsbtn { z-index: 3; }
.dock { position: absolute; z-index: 4; right: 14px; top: 14px; bottom: 14px; width: min(430px, calc(100% - 28px)); overflow: auto; padding: 16px; border-radius: 18px;
  --card: rgba(255,255,255,.06); --text: #ececf1; --muted: #a3a3b2; --line: rgba(255,255,255,.1);
  background: rgba(9,10,20,.74); -webkit-backdrop-filter: blur(16px) saturate(1.2); backdrop-filter: blur(16px) saturate(1.2);
  border: 1px solid rgba(255,255,255,.12); color: var(--text); scrollbar-width: thin;
  opacity: 0; transform: translateX(28px); pointer-events: none; transition: transform .5s var(--ease-out), opacity .3s ease; }
.dock.open { opacity: 1; transform: none; pointer-events: auto; transition-delay: .45s, .45s; }
.dhead { display: flex; gap: 8px; align-items: center; margin-bottom: 14px; flex-wrap: wrap; }
.dhead .sp { flex: 1; }
.dock .gbtn { background: rgba(255,255,255,.07); border-color: rgba(255,255,255,.14); color: #ececf1; }
.dtitle { font-size: 27px; font-weight: 700; letter-spacing: -.02em; overflow-wrap: anywhere; }
.dock .chip { color: rgba(233,233,243,.75); margin: 4px 0 8px; font-size: 13.5px; }
.dock .hstats { margin: 14px 0; }
.dock h3 { font-size: 12px; text-transform: uppercase; letter-spacing: .09em; color: var(--muted); margin: 22px 0 10px; display: flex; align-items: center; gap: 10px; font-weight: 600; }
.dock h3 .count { background: var(--line); color: var(--text); border-radius: 999px; padding: 1px 8px; font-size: 11px; }
.dlist { display: grid; gap: 10px; }
.dock .card.feed { padding: 4px 12px; }
.dock .row .u { display: inline-block; }
@media (max-width: 700px) { .dock { top: auto; left: 10px; right: 10px; bottom: 10px; width: auto; height: 58%; transform: translateY(28px); } }
@media (prefers-reduced-motion: reduce) { .dock, .dock.open { transition: opacity .2s ease; transform: none; transition-delay: 0s; } }

/* Prompt göndərmə */
.cmdbox [hidden], .cmdc [hidden] { display: none !important; }
.cmdbox textarea, .tokrow input { width: 100%; box-sizing: border-box; background: rgba(255,255,255,.06); color: #ececf1; border: 1px solid rgba(255,255,255,.14); border-radius: 12px; padding: 10px 12px; font: inherit; font-size: 14px; resize: vertical; min-height: 64px; }
.tokrow { display: flex; gap: 8px; } .tokrow input { min-height: 0; }
.cmdbox textarea:focus, .tokrow input:focus { outline: 2px solid var(--accent); outline-offset: 1px; }
.cmdbar { display: flex; align-items: center; justify-content: space-between; margin: 8px 0 10px; gap: 10px; }
.cmdwho { font-size: 12.5px; color: var(--muted); } .cmdwho a { color: var(--muted); cursor: pointer; }
.gbtn.go { background: var(--accent); border-color: var(--accent); color: #fff; font-weight: 600; }
.gbtn:disabled { opacity: .5; cursor: default; }
.cmderr { color: #f87171; font-size: 13px; margin: 6px 0; }
.agentst { font-size: 11px; text-transform: none; letter-spacing: 0; font-weight: 500; display: inline-flex; align-items: center; gap: 6px; }
.agentst i { width: 7px; height: 7px; border-radius: 50%; background: var(--off); } .agentst.on i { background: var(--idle); }
.cmdc { padding: 12px 14px; }
.cmdc .ch { display: flex; align-items: center; gap: 8px; font-size: 12.5px; color: var(--muted); }
.cmdc .ch b { color: var(--text); font-weight: 600; } .cmdc .ch .st { margin-left: auto; display: inline-flex; align-items: center; gap: 6px; }
.cmdc .cp { margin: 6px 0 2px; font-size: 14px; overflow-wrap: anywhere; white-space: pre-wrap; }
.cmdc details { margin-top: 8px; } .cmdc summary { cursor: pointer; font-size: 12.5px; color: var(--muted); }
.cmdc pre { margin: 8px 0 0; padding: 10px; border-radius: 10px; background: rgba(0,0,0,.35); font: 12.5px/1.5 ui-monospace, Menlo, monospace; white-space: pre-wrap; overflow-wrap: anywhere; max-height: 260px; overflow: auto; }
.cmdc .cx { margin-top: 6px; }

/* Giriş */
.login { max-width: 330px; margin: 18vh auto 0; }
.login h1 { margin-bottom: 4px; }
.login input, .login button { width: 100%; font: inherit; padding: 10px 12px; border-radius: 9px; border: 1px solid var(--line); margin-top: 10px; }
.login input { background: transparent; color: var(--text); }
.login button { background: var(--accent); border-color: var(--accent); color: #fff; cursor: pointer; transition: transform .15s var(--ease-out); }
.login button:active { transform: scale(.98); }
.err { color: var(--wait); margin-top: 8px; font-size: 14px; }

@media (max-width: 520px) { .row { grid-template-columns: 48px 1fr; } .wrap { padding-top: 16px; } }

/* Azaldılmış hərəkət: sonsuz fırlanma/sürüşmə/sıçrayış yox, yalnız yumşaq solma qalır */
@media (prefers-reduced-motion: reduce) {
  body::before, .logo::after, .dot::after, .avatar .ring, .bar::after, .typing i, .proj::after { animation: none !important; }
  [data-st="working"] > .person .ring, .stack .avatar[data-st="working"] .ring { opacity: .9; }
  .bar::after { width: 100%; opacity: .5; }
  .typing { display: none !important; }
  .proj[data-st="working"]::after { opacity: .6; }
  .enter, .row.enter { animation: fadein .25s ease backwards; }
  .stat b.bump, .row.fresh::before { animation: none; }
  .rig::after, .mm, .nebula, .stars, .orbit, .slot, .mo, .sun::before, .sun::after, .aura, .surf, .hplanet.landing, .pbox.pop, .scene.arrive { animation: none !important; }
  .shoot { display: none; }
  .space.warping .scene, .space.warping .skyz { transition: none; }
  @keyframes fadein { from { opacity: 0; } to { opacity: 1; } }
}
</style>
</head>
<body>
<div class="wrap">
<?php if (!$authed): ?>
  <form class="login card" method="post">
    <h1>Komanda Claude</h1>
    <input type="password" name="password" placeholder="Parol" autofocus required>
    <?php if ($error): ?><div class="err"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <button type="submit">Daxil ol</button>
  </form>
<?php else: ?>
  <header>
    <div class="brand"><div class="logo">C</div><h1>Komanda Claude</h1></div>
    <nav class="tabs"><a id="tab-panel" href="#">Panel</a><a id="tab-space" href="#kainat">Kainat</a></nav>
    <div class="meta"><span class="live" id="live"><span class="dot"></span><span id="conn">qoşulur…</span></span><a href="?logout=1">Çıxış</a></div>
  </header>

  <div id="v-panel">
  <div class="stats" id="stats"></div>

  <h2>Kim nə edir</h2>
  <div class="grid" id="people"></div>

  <h2>Proyektlər <span class="count" id="pcount">0</span></h2>
  <div class="filters" id="filters"></div>
  <div class="grid" id="projects"></div>
  <div class="empty" id="pempty" hidden>Hələ proyekt yoxdur. Hook quraşdırılmış proyektdə Claude Code işlət.</div>

  <h2>Canlı axın</h2>
  <div class="card feed" id="feed"></div>
  <div class="empty" id="fempty" hidden>Hələ heç nə yoxdur</div>
  </div>

  <div id="v-space" hidden>
    <div class="space" id="space">
      <div class="hud"><span id="hudA"></span><span id="hudB"></span></div>
      <button class="fsbtn" id="fs" title="Tam ekran" aria-label="Tam ekran">⛶</button>
      <div class="zbtns"><button id="zin" aria-label="Yaxınlaşdır">+</button><button id="zout" aria-label="Uzaqlaşdır">−</button></div>
      <div class="scene" id="scene">
        <div class="cam"><div class="rig">
          <div id="orbits"></div>
          <div class="sun"><div class="sunlbl">Komanda</div></div>
        </div></div>
      </div>
      <div class="travel" id="travel"></div>
      <aside class="dock" id="dock" aria-label="Proyekt">
        <div class="dhead">
          <button class="gbtn" id="pback">← Kainat</button><span class="sp"></span>
          <button class="gbtn" id="pprev" hidden></button><button class="gbtn" id="pnext" hidden></button>
        </div>
        <div class="dtitle" id="dtitle"></div>
        <div class="chip"><span class="dot" id="ddot"></span><span id="dlabel"></span></div>
        <div class="sline" id="dsum" style="color:rgba(233,233,243,.7)"></div>
        <div class="hstats">
          <div><b id="dst1">0</b><span>sessiya</span></div><div><b id="dst2">0</b><span>dəyişiklik</span></div>
          <div><b id="dst3">0</b><span>əməliyyat</span></div><div><b id="dst4">—</b><span>son fəaliyyət</span></div>
        </div>
        <div class="crew" id="dcrew"></div>
        <h3>Claude-a prompt göndər <span class="agentst" id="agentst"></span></h3>
        <div class="cmdbox">
          <div class="tokrow" id="tokrow" hidden>
            <input id="tokin" type="password" autocomplete="off" placeholder="Öz tokenin (bir dəfə, bu brauzerdə qalır)">
            <button class="gbtn" id="toksave">Təsdiq et</button>
          </div>
          <div id="cmdmain" hidden>
            <textarea id="cmdin" rows="3" maxlength="4000" placeholder="Bu proyektdə nə etsin? (Cmd/Ctrl+Enter ilə göndər)"></textarea>
            <div class="cmdbar"><span class="cmdwho" id="cmdwho"></span><button class="gbtn go" id="cmdsend">Göndər</button></div>
          </div>
          <div class="cmderr" id="cmderr" hidden></div>
          <div class="dlist" id="cmdlist"></div>
        </div>
        <h3>Canlı işlər <span class="count" id="pscount">0</span></h3>
        <div class="dlist" id="psess"></div>
        <div class="empty" id="psempty" hidden>Bu proyektdə hələ sessiya yoxdur</div>
        <h3>Proyektin axını</h3>
        <div class="card feed" id="pfeed"></div>
        <div class="empty" id="pfempty" hidden>Hələ heç nə yoxdur</div>
      </aside>
      <div class="sempty" id="sempty" hidden>Hələ heç bir dünya yoxdur. Hook quraşdırılmış proyektdə Claude Code işlət, ilk planet yaranacaq.</div>
    </div>
  </div>


<script type="importmap">{"imports":{"three":"https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js","three/addons/":"https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/"}}</script>
<script type="module" src="kainat.js?v=<?= (int)@filemtime(__DIR__ . '/kainat.js') ?>"></script>
<script>
const STATUS = { working: 'işləyir', waiting: 'səni gözləyir', idle: 'gözləyir', ended: 'bağlandı', offline: 'oflayn' };
const EDITS = ['Edit', 'Write', 'MultiEdit', 'NotebookEdit'];
const $ = id => document.getElementById(id);
const RANK = { waiting: 3, working: 2, idle: 1, offline: 0, ended: 0 };
let data = null, offset = 0, filter = 'all', first = true, lastOk = 0;
let view = 'panel', curPlanet = null, stagger = false, quiet = false, warping = false;
const primed = {};
const REDUCE = matchMedia('(prefers-reduced-motion: reduce)').matches;
const MAXP = 8;
function prime(id, fn) { const un = !primed[id]; stagger = quiet = un; fn(); primed[id] = true; stagger = quiet = false; }

const hue = s => { let h = 0; for (const c of s) h = (h * 31 + c.charCodeAt(0)) % 360; return h; };
const tint = u => `hsl(${hue(u)} 58% 50%)`;
const now = () => Date.now() / 1000 + offset;
function el(tag, cls, text) { const n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; }
function setText(n, t) { if (n.textContent !== t) n.textContent = t; }
function setSt(n, st) { if (n.dataset.st !== st) n.dataset.st = st; }
function setCls(n, c) { if (n.className !== c) n.className = c; }
function ago(ts) {
  const s = Math.max(0, Math.floor(now() - ts));
  if (s < 10) return 'indi';
  if (s < 60) return s + ' san əvvəl';
  if (s < 3600) return Math.floor(s / 60) + ' dəq əvvəl';
  if (s < 86400) return Math.floor(s / 3600) + ' saat əvvəl';
  return Math.floor(s / 86400) + ' gün əvvəl';
}
const clock = ts => new Date(ts * 1000).toLocaleTimeString('az', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
function eff(s) {
  if (s.status === 'ended') return 'ended';
  return now() - s.updated_at > 900 ? 'offline' : s.status;      // 15 dəq səssizlik = oflayn
}
function avatar(u) {
  const a = el('div', 'avatar'); a.style.background = tint(u);
  a.append(el('span', 'ring'), el('span', null, u[0].toUpperCase()));
  return a;
}

/* Açarlı yeniləmə: mövcud elementlər yerində qalır ki, sonsuz animasiyalar kəsilməsin */
function sync(parent, items, key, make, update, opts) {
  const have = new Map();
  for (const c of parent.children) have.set(c.dataset.k, c);
  let prev = null, i = 0;
  for (const it of items) {
    const k = key(it);
    let n = have.get(k);
    if (n) have.delete(k);
    else {
      n = make(it); n.dataset.k = k;
      if (!opts || opts.enter !== false) { n.classList.add('enter'); n.style.setProperty('--i', stagger ? Math.min(i, 10) : 0); }
    }
    update(n, it);
    const ref = prev ? prev.nextSibling : parent.firstChild;
    if (n !== ref) parent.insertBefore(n, ref);
    prev = n; i++;
  }
  have.forEach(n => n.remove());
}

/* ---- Statistika ---- */
const statDefs = [['working', 'İndi işləyir'], ['active', 'Aktiv sessiya'], ['edits', 'Dəyişiklik (24 saat)'], ['projects', 'Proyekt (30 gün)']];
function renderStats(v) {
  const box = $('stats');
  if (!box.children.length) for (const [k, label] of statDefs) {
    const s = el('div', 'stat'); s.dataset.k = k; s.append(el('b', null, '0'), el('span', null, label)); box.append(s);
  }
  for (const s of box.children) {
    const b = s.firstChild, val = String(v[s.dataset.k]);
    if (b.textContent !== val) {
      const initial = b.textContent === '0' && first;
      b.textContent = val;
      if (!initial) { b.classList.remove('bump'); void b.offsetWidth; b.classList.add('bump'); }
    }
  }
}

/* ---- Adamlar ---- */
function makePerson(u) {
  const n = el('article', 'card');
  const p = el('div', 'person'), av = avatar(u), info = el('div');
  const chip = el('div', 'chip'), dot = el('span', 'dot'), label = el('span');
  chip.append(dot, label); info.append(el('div', 'pname', u), chip); p.append(av, info);
  const list = el('div'), empty = el('div', 'empty', 'Hazırda aktiv sessiya yoxdur');
  n.append(p, list, empty);
  n._r = { dot, label, list, empty };
  return n;
}
function makeSession() {
  const n = el('div', 'sess');
  const head = el('div', 'shead'), dot = el('span', 'dot'), proj = el('span');
  head.append(dot, proj);
  const prompt = el('div', 'sprompt'), line = el('div', 'sline'), sum = el('span', 't');
  const typing = el('span', 'typing'); typing.append(el('i'), el('i'), el('i'));
  line.append(typing, sum);
  const chips = el('div', 'chips'), a = el('span'), e = el('span'), t = el('span');
  chips.append(a, e, t);
  n.append(head, prompt, line, el('div', 'bar'), chips);
  n._r = { dot, proj, prompt, sum, a, e, t };
  return n;
}
function renderPeople() {
  sync($('people'), data.users, u => u, makePerson, (n, u) => {
    const r = n._r;
    const mine = data.sessions.filter(s => s.user === u).map(s => ({ ...s, st: eff(s) })).filter(s => RANK[s.st] > 0);
    const top = mine.reduce((m, s) => Math.max(m, RANK[s.st]), 0);
    const st = ['offline', 'idle', 'working', 'waiting'][top];
    setSt(n, st); setCls(r.dot, 'dot ' + st); setText(r.label, STATUS[st]);
    r.empty.hidden = mine.length > 0;
    sync(r.list, mine, s => s.session_id, makeSession, (sn, s) => {
      const q = sn._r;
      setSt(sn, s.st); setCls(q.dot, 'dot ' + s.st);
      setText(q.proj, s.project);
      setText(q.prompt, s.last_prompt ? '“' + s.last_prompt + '”' : ''); q.prompt.hidden = !s.last_prompt;
      setText(q.sum, s.last_summary);
      setText(q.a, ago(s.updated_at)); setText(q.e, s.edits + ' dəyişiklik'); setText(q.t, s.tool_count + ' əməliyyat');
    });
  });
}

/* ---- Proyektlər ---- */
function buildProjects() {
  const m = new Map();
  for (const r of data.projects) {
    let p = m.get(r.project);
    if (!p) { p = { name: r.project, users: new Map(), edits: 0, tools: 0, sessions: 0, last: 0, st: 'offline', summary: '', sumAt: 0 }; m.set(r.project, p); }
    p.users.set(r.user, { st: 'offline' });
    p.edits += +r.edits; p.tools += +r.tools; p.sessions += +r.sessions; p.last = Math.max(p.last, +r.last_at);
  }
  for (const s of data.sessions) {
    const p = m.get(s.project); if (!p) continue;
    const st = eff(s), u = p.users.get(s.user);
    if (u && RANK[st] > RANK[u.st]) u.st = st;
    if (RANK[st] > RANK[p.st]) p.st = st;
    if (s.updated_at >= p.sumAt) { p.sumAt = s.updated_at; p.summary = s.user + ' · ' + s.last_summary; }
  }
  return [...m.values()].sort((a, b) => b.last - a.last);
}
function makeProject() {
  const n = el('article', 'card proj');
  const head = el('div', 'pjhead'), title = el('div', 'pjtitle'), dot = el('span', 'dot'), name = el('span', 'pjname');
  title.append(dot, name);
  const stack = el('div', 'stack');
  head.append(title, stack);
  const sum = el('div', 'pjsum');
  const foot = el('div', 'pjfoot'), nums = el('div', 'pjnums'), a = el('span'), e = el('span'), t = el('span'), s = el('span');
  nums.append(s, e, t); foot.append(a, nums);
  n.append(head, sum, foot);
  n._r = { dot, name, stack, sum, a, e, t, s };
  n.tabIndex = 0; n.setAttribute('role', 'link');
  n.onclick = () => go(n.dataset.k);
  n.onkeydown = ev => { if (ev.key === 'Enter') go(n.dataset.k); };
  return n;
}
function renderProjects() {
  const all = buildProjects();
  $('pcount').textContent = all.length;
  const list = all.filter(p => filter === 'all' || p.users.has(filter)).slice(0, 12);
  $('pempty').hidden = list.length > 0;
  sync($('projects'), list, p => p.name, makeProject, (n, p) => {
    const r = n._r;
    setSt(n, p.st); setCls(r.dot, 'dot ' + p.st);
    setText(r.name, p.name);
    setText(r.sum, p.st === 'offline' || p.st === 'ended' ? '' : p.summary);
    setText(r.a, ago(p.last));
    setText(r.s, p.sessions + ' sessiya'); setText(r.e, p.edits + ' dəyişiklik'); setText(r.t, p.tools + ' əməliyyat');
    sync(r.stack, [...p.users.entries()], ([u]) => u, ([u]) => avatar(u), (an, [u, v]) => { setSt(an, v.st); an.title = u; });
  });
}
function renderFilters() {
  sync($('filters'), ['all', ...data.users], f => f, f => {
    const b = el('button', null, f === 'all' ? 'Hamısı' : f);
    b.onclick = () => { filter = f; render(); };
    return b;
  }, (b, f) => setCls(b, f === filter ? 'on' : ''));
}

/* ---- Canlı axın ---- */
function rowKind(e) {
  if (e.event === 'UserPromptSubmit') return 'k-prompt';
  if (e.event === 'Stop') return 'k-stop';
  if (e.event === 'Notification') return 'k-wait';
  if (EDITS.includes(e.tool)) return 'k-edit';
  return '';
}
function makeRow(e) {
  const n = el('div', 'row ' + rowKind(e));
  const s = el('div', 's'), u = el('span', 'u', e.user); u.style.color = tint(e.user);
  s.append(el('i', 'k'), u, document.createTextNode(e.summary + ' '), el('small', null, '· ' + e.project));
  n.append(el('div', 't', clock(e.created_at)), s);
  if (!quiet) n.classList.add('fresh');
  return n;
}
function renderFeedInto(box, empty, evs, id) {
  evs = evs.slice(0, 40);
  empty.hidden = evs.length > 0; box.hidden = evs.length === 0;
  prime(id, () => sync(box, evs, e => e.id, makeRow, () => {}));
}

/* ====== Kainat: planetlər ====== */
function stars(n, w, h, glow) {
  const a = [];
  for (let i = 0; i < n; i++)
    a.push(`${(Math.random() * w - 60).toFixed(0)}px ${(Math.random() * h - 60).toFixed(0)}px 0 ${glow ? '.6px' : '0'} rgba(255,255,255,${(.35 + Math.random() * .65).toFixed(2)})`);
  return a.join(',');
}
function makeSky(box, w, h, k) {
  const z = el('div', 'skyz'); z.append(el('div', 'nebula'));
  for (const [n, c] of [[90, 's1'], [38, 's2'], [10, 's3']]) {
    const d = el('div', 'stars ' + c); d.style.boxShadow = stars(Math.round(n * k), w, h, c === 's3'); z.append(d);
  }
  for (let i = 0; i < 2; i++) {
    const t = el('div', 'shoot');
    t.style.setProperty('--sx', (8 + Math.random() * 50) + '%'); t.style.setProperty('--sy', (4 + Math.random() * 35) + '%');
    t.style.setProperty('--sd', (i * 6 + Math.random() * 4) + 's'); z.append(t);
  }
  box.prepend(z);
}
function makePlanet(h) {
  const p = el('div', 'planet'); p.style.setProperty('--h', h);
  const body = el('div', 'body'); body.append(el('div', 'surf'));
  p.append(el('div', 'aura'), body);
  if (h % 3 === 0) p.append(el('div', 'ringd'));
  p.append(el('div', 'moons'));
  return p;
}
function syncMoons(planet, users) {
  const box = planet.querySelector('.moons');
  sync(box, [...users.entries()], ([u]) => u, ([u]) => {
    const mo = el('div', 'mo'), mm = el('div', 'mm'), m = el('i', 'moon');
    m.style.background = tint(u); m.style.color = tint(u);
    mo.style.setProperty('--d', (-(hue(u) % 100) / 100 * 14) + 's'); mo.title = u; mm.append(m); mo.append(mm); return mo;
  }, (mo, [u, v]) => {
    setSt(mo, v.st);
    const r = String(-(22 + [...box.children].indexOf(mo) * 9));
    if (mo._r !== r) { mo._r = r; mo.style.setProperty('--r', r); }
  }, { enter: false });
}
function planetSub(p) { return RANK[p.st] > 0 ? STATUS[p.st] : ago(p.last); }

function makeOrbit(p) {
  const o = el('div', 'orbit'), sl = el('div', 'slot'), b = el('button', 'pbox pop');
  const h = hue(p.name), T = 150 + (h % 90);
  o.style.setProperty('--T', T + 's');
  o.style.setProperty('--dl', (-((h * 7) % 360) / 360 * T) + 's');
  if (stagger) b.style.setProperty('--i', h % 6);
  b.style.setProperty('--z', ((h % 7) - 3) * 0.9);
  const planet = makePlanet(h), label = el('div', 'plabel'), nm = el('b'), sub = el('span');
  label.append(nm, sub); b.append(planet, label); sl.append(b); o.append(sl);
  b.onclick = () => { if (dragged) { dragged = false; return; } warp(o.dataset.k, b); };
  o._r = { b, planet, nm, sub };
  return o;
}
function renderSpace() {
  const all = buildProjects();
  const list = all.slice(0, MAXP).sort((a, b) => a.name.localeCompare(b.name));
  setText($('hudA'), all.length + ' proyekt');
  setText($('hudB'), all.filter(p => p.st === 'working').length + ' işləyir');
  $('sempty').hidden = all.length > 0;
  if (K && glOn) {
    K.setData(list.map(p => ({ name: p.name, st: p.st, edits: p.edits, tools: p.tools, sub: planetSub(p),
      users: [...p.users].map(([u, v]) => ({ name: u, st: v.st, color: tint(u) })) })));
  } else {
    const step = Math.min(9, 46 / Math.max(list.length, 1));
    prime('orbits', () => sync($('orbits'), list, p => p.name, makeOrbit, (o, p) => {
      const r = o._r, d = (48 + list.indexOf(p) * step).toFixed(1);
      if (o._d !== d) { o._d = d; o.style.setProperty('--d', d); }
      const sz = (5 + Math.min(5, Math.log2(1 + p.edits + p.tools / 4) * .6)).toFixed(1);
      if (r.b._s !== sz) { r.b._s = sz; r.b.style.setProperty('--s', sz); }
      setSt(r.b, p.st); setText(r.nm, p.name); setText(r.sub, planetSub(p));
      syncMoons(r.planet, p.users);
    }, { enter: false }));
  }
  prime('travel', () => sync($('travel'), list, p => p.name, p => {
    const b = el('button'), d = el('i', 'tdot'); d.style.setProperty('--h', hue(p.name)); b.append(d, el('span', null, p.name));
    b.onclick = () => go(p.name); return b;
  }, () => {}));
  if (curPlanet) renderDock(all);
}
/* ====== 3D kamera: sürüşdür = fırlat/əy, boş vaxtda yavaş dönür ====== */
const cam = { tx: 58, rz: -18, auto: !REDUCE };
let dragged = false, drag = null, lastT = 0;
function applyCam() {
  const sp = $('space');
  sp.style.setProperty('--tx', cam.tx.toFixed(2)); sp.style.setProperty('--rz', cam.rz.toFixed(2));
}
function camLoop(t) {
  const dt = Math.min(.1, (t - lastT) / 1000 || 0); lastT = t;
  if (view === 'space' && cam.auto && !drag && !warping && !document.hidden && !$('scene').querySelector('.pbox:hover')) {
    cam.rz = (cam.rz + dt * 1.2) % 360; applyCam();
  }
  requestAnimationFrame(camLoop);
}
function initCam() {
  applyCam();
  $('scene').addEventListener('pointerdown', e => { drag = { x: e.clientX, y: e.clientY, tx: cam.tx, rz: cam.rz }; dragged = false; });
  addEventListener('pointermove', e => {
    if (!drag) return;
    const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
    if (Math.abs(dx) + Math.abs(dy) > 5) dragged = true;
    if (!dragged) return;
    cam.rz = drag.rz + dx * .35; cam.tx = Math.max(38, Math.min(80, drag.tx - dy * .25)); applyCam();
  });
  addEventListener('pointerup', () => { drag = null; });
  addEventListener('pointercancel', () => { drag = null; });
  requestAnimationFrame(camLoop);
}
function warp(name, btn) {
  if (REDUCE || warping) return go(name);
  warping = true;
  const sc = $('scene'), r = btn.getBoundingClientRect(), s = sc.getBoundingClientRect();
  sc.style.transformOrigin = (r.left + r.width / 2 - s.left) + 'px ' + (r.top + r.height / 2 - s.top) + 'px';
  $('space').classList.add('warping');
  setTimeout(() => { warping = false; go(name); }, 520);
}

/* ====== Planet paneli (dock) ====== */
function makePSess(s) {
  const n = el('article', 'card sess pcard');
  const head = el('div', 'shead'), nm = el('span', null, s.user), st = el('span', 'st'), dot = el('span', 'dot'), lab = el('span');
  st.append(dot, lab); head.append(avatar(s.user), nm, st);
  const prompt = el('div', 'sprompt'), line = el('div', 'sline'), sum = el('span', 't');
  const typing = el('span', 'typing'); typing.append(el('i'), el('i'), el('i')); line.append(typing, sum);
  const chips = el('div', 'chips'), a = el('span'), e = el('span'), t = el('span'); chips.append(a, e, t);
  n.append(head, prompt, line, el('div', 'bar'), chips);
  n._r = { dot, lab, prompt, sum, a, e, t };
  return n;
}
/* ====== Prompt göndərmə (yalnız öz maşınına) ====== */
const TKEY = 'tdtoken';
let myName = null, cmdBusy = false;
const getTok = () => { try { return localStorage.getItem(TKEY) || ''; } catch (e) { return ''; } };
const setTok = v => { try { v ? localStorage.setItem(TKEY, v) : localStorage.removeItem(TKEY); } catch (e) {} };
async function cmdApi(action, extra) {
  const r = await fetch('command.php', { method: 'POST', headers: { 'X-Team-Token': getTok(), 'Content-Type': 'application/json' }, body: JSON.stringify({ action, ...extra }) });
  const d = await r.json().catch(() => ({}));
  if (r.status === 401) { setTok(''); myName = null; }
  return { status: r.status, d };
}
async function identify() {
  if (!getTok()) { myName = null; return; }
  try { const { status, d } = await cmdApi('whoami'); myName = status === 200 ? d.user : null; } catch (e) { myName = null; }
}
const CMD_ST = { queued: ['növbədə', 'offline'], running: ['işləyir', 'working'], done: ['bitdi', 'idle'], failed: ['xəta', 'waiting'], canceled: ['ləğv edildi', 'offline'] };
function makeCmd() {
  const n = el('div', 'card cmdc');
  const h = el('div', 'ch'), who = el('b'), when = el('span'), st = el('span', 'st'), dot = el('span', 'dot'), lab = el('span');
  st.append(dot, lab); h.append(who, when, st);
  const cp = el('div', 'cp'), det = el('details'), sm = el('summary', null, 'Nəticə'), pre = el('pre');
  det.append(sm, pre);
  const cx = el('button', 'gbtn cx', 'Ləğv et'); cx.hidden = true;
  n.append(h, cp, det, cx);
  n._r = { who, when, dot, lab, cp, det, pre, cx };
  return n;
}
function renderCmd() {
  if (!data) return;
  const on = !!(getTok() && myName);
  $('tokrow').hidden = on; $('cmdmain').hidden = !on;
  if (on) {
    const w = $('cmdwho');
    if (!w.dataset.n || w.dataset.n !== myName) {
      w.dataset.n = myName; w.replaceChildren(document.createTextNode(myName + ' kompüterinə · '), Object.assign(el('a', null, 'tokeni sil'), { onclick: () => { setTok(''); myName = null; renderCmd(); } }));
    }
    const ag = (data.agents || []).find(a => a.user === myName);
    const live = ag && now() - ag.last_seen < 20;
    const s = $('agentst'); setCls(s, 'agentst' + (live ? ' on' : ''));
    s.replaceChildren(el('i'), document.createTextNode(live ? 'agent onlayn' : 'agent oflayn'));
    s.title = live ? '' : 'Kompüterində işlət: python3 agent/claude-team-agent.py';
  } else { const s = $('agentst'); s.replaceChildren(); setCls(s, 'agentst'); }
  const list = (data.commands || []).filter(c => c.project === curPlanet);
  sync($('cmdlist'), list, c => c.id, makeCmd, (n, c) => {
    const r = n._r, [lbl, dc] = CMD_ST[c.status] || [c.status, 'offline'];
    setText(r.who, c.user); setText(r.when, ago(c.created_at));
    setCls(r.dot, 'dot ' + dc); setText(r.lab, lbl);
    setText(r.cp, c.prompt);
    const hasRes = c.status === 'done' || c.status === 'failed';
    r.det.hidden = !hasRes; setText(r.pre, c.result || '');
    if (hasRes && !r.det._opened) { r.det._opened = true; r.det.open = c.status === 'failed' || (c.result || '').length < 400; }
    r.cx.hidden = !(c.status === 'queued' && c.user === myName);
    r.cx.onclick = async () => { await cmdApi('cancel', { id: c.id }); load(); };
  });
}
function cmdError(t) { const e = $('cmderr'); e.hidden = !t; e.textContent = t || ''; }
async function sendCmd() {
  const ta = $('cmdin'), text = ta.value.trim();
  if (!text || cmdBusy || !curPlanet) return;
  cmdBusy = true; $('cmdsend').disabled = true; cmdError('');
  try {
    const { status, d } = await cmdApi('send', { project: curPlanet, prompt: text });
    if (status === 200) { ta.value = ''; load(); }
    else cmdError(status === 401 ? 'Token yanlışdır, yenidən daxil et.' : (d.error || 'Göndərmək alınmadı'));
  } catch (e) { cmdError('Bağlantı xətası'); }
  cmdBusy = false; $('cmdsend').disabled = false; renderCmd();
}
function initCmd() {
  $('cmdsend').onclick = sendCmd;
  $('cmdin').addEventListener('keydown', e => { if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) { e.preventDefault(); sendCmd(); } });
  $('toksave').onclick = async () => {
    const v = $('tokin').value.trim(); if (!v) return;
    setTok(v); $('tokin').value = ''; await identify();
    if (!myName) cmdError('Token yanlışdır.'); else cmdError('');
    renderCmd();
  };
  $('tokin').addEventListener('keydown', e => { if (e.key === 'Enter') $('toksave').click(); });
  identify().then(renderCmd);
}

function renderDock(all) {
  const p = all.find(x => x.name === curPlanet) || { name: curPlanet, users: new Map(), edits: 0, tools: 0, sessions: 0, last: 0, st: 'offline', summary: '' };
  $('dock').classList.add('open');
  setText($('dtitle'), curPlanet);
  setCls($('ddot'), 'dot ' + p.st);
  setText($('dlabel'), p.last ? (RANK[p.st] > 0 ? STATUS[p.st] : 'sonuncu fəaliyyət ' + ago(p.last)) : 'bu proyekt üçün məlumat yoxdur');
  setText($('dsum'), RANK[p.st] > 0 ? p.summary : '');
  setText($('dst1'), String(p.sessions)); setText($('dst2'), String(p.edits)); setText($('dst3'), String(p.tools));
  setText($('dst4'), p.last ? ago(p.last) : '—');
  sync($('dcrew'), [...p.users.entries()], ([u]) => u, ([u]) => { const c = el('div', 'crewm'); c.append(avatar(u), el('span', null, u)); return c; }, (c, [, v]) => setSt(c, v.st));

  const names = all.map(x => x.name).sort((a, b) => a.localeCompare(b));
  const i = names.indexOf(curPlanet), prev = names[(i - 1 + names.length) % names.length], next = names[(i + 1) % names.length];
  const multi = names.length > 1 && i >= 0;
  for (const [id, nm, lbl] of [['pprev', prev, '‹ '], ['pnext', next, ' ›']]) {
    const b = $(id); b.hidden = !multi;
    if (multi) { setText(b, id === 'pprev' ? lbl + nm : nm + lbl); b.onclick = () => go(nm); }
  }
  const ss = data.sessions.filter(x => x.project === curPlanet).map(x => ({ ...x, st: eff(x) }))
    .sort((a, b) => RANK[b.st] - RANK[a.st] || b.updated_at - a.updated_at);
  setText($('pscount'), String(ss.filter(x => RANK[x.st] > 0).length));
  $('psempty').hidden = ss.length > 0;
  prime('psess:' + curPlanet, () => sync($('psess'), ss, x => x.session_id, makePSess, (n, x) => {
    const q = n._r;
    setSt(n, x.st); setCls(q.dot, 'dot ' + x.st); setText(q.lab, STATUS[x.st]);
    setText(q.prompt, x.last_prompt ? '“' + x.last_prompt + '”' : ''); q.prompt.hidden = !x.last_prompt;
    setText(q.sum, x.last_summary);
    setText(q.a, ago(x.updated_at)); setText(q.e, x.edits + ' dəyişiklik'); setText(q.t, x.tool_count + ' əməliyyat');
  }));
  renderFeedInto($('pfeed'), $('pfempty'), data.events.filter(e => e.project === curPlanet), 'pfeed:' + curPlanet);
  renderCmd();
}

/* ====== Görünüşlər və naviqasiya ====== */
function go(name) { location.hash = name ? '#kainat/' + encodeURIComponent(name) : '#kainat'; }
let K = null, glOn = false;
function initGL() {
  if (glOn) return;
  K = window.Kainat;
  if (!K || !K.mount($('space'))) { K = null; return; }
  glOn = true;
  $('space').classList.add('gl');
  K.onPick = name => go(name);
  $('zin').onclick = () => K.zoom(.78); $('zout').onclick = () => K.zoom(1.28);
  K.setActive(view === 'space');
  if (view === 'space') { render(); K.focus(curPlanet); }
}
function setView(v, name) {
  view = v; curPlanet = v === 'space' ? (name || null) : null;
  document.body.classList.toggle('v-space', v === 'space');
  $('v-panel').hidden = v !== 'panel'; $('v-space').hidden = v !== 'space';
  $('tab-panel').classList.toggle('on', v === 'panel'); $('tab-space').classList.toggle('on', v !== 'panel');
  $('dock').classList.toggle('open', !!curPlanet);
  $('space').classList.remove('warping'); $('scene').style.transformOrigin = '';
  if (v === 'space' && !glOn) { const sc = $('scene'); sc.classList.remove('arrive'); void sc.offsetWidth; sc.classList.add('arrive'); }
  if (K) { K.setActive(v === 'space'); K.focus(curPlanet); }
  render(); load();
}
function route() {
  const [v, p] = location.hash.slice(1).split('/');
  if (v === 'kainat') setView('space', p ? decodeURIComponent(p) : null);
  else setView('panel');
}
function renderPanel() {
  const act = data.sessions.filter(s => RANK[eff(s)] > 0);
  renderStats({
    working: act.filter(s => eff(s) === 'working').length,
    active: act.length,
    edits: data.sessions.reduce((a, s) => a + (+s.edits || 0), 0),
    projects: new Set(data.projects.map(p => p.project)).size,
  });
  prime('people', renderPeople); prime('filters', renderFilters); prime('projects', renderProjects);
  renderFeedInto($('feed'), $('fempty'), data.events.filter(e => filter === 'all' || e.user === filter), 'feed');
}
function render() {
  if (!data) return;
  if (view === 'panel') renderPanel(); else renderSpace();
  first = false;
}

async function load() {
  if (document.hidden) return;
  try {
    const r = await fetch('feed.php' + (view === 'space' && curPlanet ? '?project=' + encodeURIComponent(curPlanet) : ''), { cache: 'no-store' });
    if (r.status === 401) return location.reload();
    data = await r.json();
    offset = data.now - Date.now() / 1000;
    lastOk = Date.now();
    render();
  } catch (e) { /* növbəti cəhd 3 san sonra */ }
}
function pulse() {                                    // hər saniyə: vaxtlar və statuslar canlı yenilənir
  const ok = Date.now() - lastOk < 9000;
  const live = $('live');
  if (ok) live.removeAttribute('data-off'); else live.setAttribute('data-off', '');
  setText($('conn'), ok ? 'canlı · ' + clock(now()) : 'bağlantı yoxdur');
  if (data && !document.hidden) render();
}
makeSky($('space'), 2400, 1500, 3.4);
initCmd();
if (document.fullscreenEnabled) $('fs').onclick = () => document.fullscreenElement ? document.exitFullscreen() : $('space').requestFullscreen();
else $('fs').hidden = true;
initCam();
$('pback').onclick = () => go();
addEventListener('hashchange', route);
addEventListener('keydown', e => {
  if (!(view === 'space' && curPlanet) || e.target.closest('input,textarea')) return;
  if (e.key === 'Escape') go();
  else if (e.key === 'ArrowLeft' && !$('pprev').hidden) $('pprev').click();
  else if (e.key === 'ArrowRight' && !$('pnext').hidden) $('pnext').click();
});
setInterval(load, 3000);
setInterval(pulse, 1000);
document.addEventListener('visibilitychange', load);
addEventListener('kainat-ready', initGL);
route();
if (window.Kainat) initGL();
</script>
<?php endif; ?>
</div>
</body>
</html>
